#include "ofApp.h"
#include"globalSettings.h"
#include "plane.h"
#include"sphere.h"
#include"cone.h"
#include"ellipsoid.h"
#include"TBASE.h"
#include"Shading.h"

#include<time.h>

plane Plane = plane(planeY, PlaneColor);
//sphere Sphere = sphere(f3Vector(0, 0, 0), 0.5, SphereColor);
sphere Sphere = sphere(f3Vector(0, 1, 2), 1, SphereColor);
cone Cone = cone(f3Vector(0, -1.5, 2), 30, 1, ConeColor);
ellipsoid Ellipsoid = ellipsoid(1, 1, 4, -3, 2, 2, EllipsoidColor);
base Base = base(f3Vector(0, -1, 1), 1, f3Vector(0,1,0),f3Vector(0.5, 0.7, 0.7));
//--------------------------------------------------------------
void ofApp::setup() {
	//set up parameters
	w = ofGetWidth();
	h = ofGetHeight();
	colorPixels.allocate(w, h, OF_PIXELS_RGB);
	int viewTYPE = 1;//0 for parallel,1 for perspective
	

	
	float left = -2.0, right = 2.0, top = 1.5, bottom = -1.5;
	// color pixels, use x and y to control red and green
	clock_t start = clock();
	for (int y = 0; y < h; y++) {
		for (int x = 0; x < w; x++) {
			pixelVec = f3Vector(left + (right - left) * (x + 0.5) / w, top - (top - bottom) * (y + 0.5) / h, ViewPlaneZ);
			if (viewTYPE == 1) {
				viewPoint = f3Vector(0, 0, -1);
			}
			else {
				viewPoint = f3Vector(pixelVec.x, pixelVec.y, -1);
			}
			ray r = ray(viewPoint, pixelVec);
			HITPOINT thp;
			for (int o = 1; o <= OBJECTNUM; o++) {
				if (o == PLANE) {
					thp = Plane.hit(r);
				}
				if (o == SPHERE) {
					thp = Sphere.hit(r);
				}
				if (o == CONE) {
					thp = Cone.hit(r);
				}
				if (o == ELLIPSOID) {
					thp = Ellipsoid.hit(r);
				}
				if (thp.t1 < hp.t1) {
					hp = thp;//get the closest point

				}
			}
			
			bool Test = false;
				//start the calculation of interpoint
				if (hp.surfacetype != 0) {
					f3Vector mcolors;//total colors
					//multiple lights
					for (int t = 0; t < Lights.size(); t++) {
						//cout << t << ":" << "(" << Lights[t].x << "," << Lights[t].y << "," << Lights[t].z << "��" << endl;
						f3Vector tLight = Lights[t];
						//cout << t << ":" << "(" << tLight.x << "," << tLight.y << "," << tLight.z << "��" << endl;
						interPoint = r.InterPoint(hp.t1);
						//Get the norm of the surface
						int TYPE = hp.surfacetype;
						switch (TYPE) {
						case PLANE:		NormVec3 = Plane.getNormVec();
							break;
						case SPHERE:	NormVec3 = Sphere.getNormVec(interPoint); break;
						case CONE:	NormVec3 = Cone.getNormVec(interPoint);  Test=true; break;
						case ELLIPSOID:	NormVec3 = Ellipsoid.getNormVec(interPoint); break;
						//case BASE:cout << "CONE BASE" << endl; colorPixels.setColor(x, y, ofColor(1* 255, 0.5 * 255,0.7 * 255)); continue;
						//case BASE:NormVec3 = f3Vector(0, -1, 0); cout << "cone BASE" << endl; break;
						}

						f3Vector viewVec = viewPoint - pixelVec;
						viewVec.normalize();
						f3Vector PhongcolorFactors;
						
						
						f3Vector MrayDir = r.dir - NormVec3 * 2 * (r.dir * NormVec3);
						MrayDir.normalize();
						f3Vector mirrorColor;
						
						f3Vector AmColor;
						AmColor = AmbientShading(hp.MaterialColors);
						
						
						PhongcolorFactors = PhongLightingModel(tLight, interPoint, NormVec3, hp.MaterialColors, viewVec, hp);
						mirrorColor = mirrorReflection(interPoint, MrayDir);
						mcolors = mcolors + PhongcolorFactors + mirrorColor + AmColor;
						ColorSpace(mcolors);
					}	
					colorPixels.setColor(x, y, ofColor((mcolors.x) * 255, (mcolors.y) * 255, (mcolors.z) * 255));

				}
				else {
					colorPixels.setColor(x, y, ofColor(0, 0, 0));
				}
				hp.intialize();

			/*
			//code for checking the shape

						if (hp.surfacetype != 0) {
				colorPixels.setColor(x, y, ofColor(0.9 * 255, 0* 255, 0 * 255));//check about the shape
			}
			else {
				colorPixels.setColor(x, y, ofColor(0, 0, 0));
			}
			hp.intialize();
			*/

		}
	}
	clock_t end = clock();
	double elapsed = double(end - start) / CLOCKS_PER_SEC;
	printf("Time measured: %.3f seconds.\n", elapsed);
	texColor.allocate(colorPixels);
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw() {
	ofSetHexColor(0xffffff);
	texColor.draw(0, 0, w, h);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
